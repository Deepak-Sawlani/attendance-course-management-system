from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
import uuid

app = Flask(__name__)
CORS(app)

# In-memory storage (for demo). Replace with DB for production.
users = []
courses = []
attendance = []

@app.route('/api/ping', methods=['GET'])
def ping():
    return jsonify({'status':'ok'})

# Users (simple)
@app.route('/api/users', methods=['POST'])
def add_user():
    data = request.json
    user = {
        'id': str(uuid.uuid4()),
        'name': data.get('name'),
        'email': data.get('email')
    }
    users.append(user)
    return jsonify(user), 201

# Courses
@app.route('/api/courses', methods=['GET','POST'])
def courses_route():
    if request.method == 'GET':
        return jsonify(courses)
    data = request.json
    course = {
        'id': str(uuid.uuid4()),
        'title': data.get('title'),
        'description': data.get('description')
    }
    courses.append(course)
    return jsonify(course), 201

@app.route('/api/courses/<course_id>', methods=['PUT','DELETE'])
def modify_course(course_id):
    global courses
    if request.method == 'DELETE':
        courses = [c for c in courses if c['id'] != course_id]
        return jsonify({'deleted': True})
    data = request.json
    for c in courses:
        if c['id'] == course_id:
            c['title'] = data.get('title', c['title'])
            c['description'] = data.get('description', c['description'])
            return jsonify(c)
    return jsonify({'error':'not found'}), 404

# Attendance punch
@app.route('/api/attendance/punch', methods=['POST'])
def punch():
    data = request.json
    rec = {
        'id': str(uuid.uuid4()),
        'user_email': data.get('user_email'),
        'type': data.get('type', 'in'),  # 'in' or 'out'
        'time': datetime.utcnow().isoformat() + 'Z'
    }
    attendance.append(rec)
    return jsonify(rec), 201

@app.route('/api/attendance', methods=['GET'])
def get_attendance():
    return jsonify(attendance)

if __name__ == '__main__':
    app.run(port=5000, debug=True)