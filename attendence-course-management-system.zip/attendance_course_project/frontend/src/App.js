import React from 'react';
import Attendance from './components/Attendance';
import Courses from './components/Courses';

export default function App(){
  return (
    <div className="container">
      <div className="header">
        <h2>Training Project — Attendance & Course Management</h2>
      </div>
      <Attendance />
      <hr />
      <Courses />
    </div>
  )
}