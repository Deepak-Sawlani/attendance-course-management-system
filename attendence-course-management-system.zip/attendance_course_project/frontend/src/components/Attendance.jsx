import React, {useState, useEffect} from 'react';
import axios from 'axios';

export default function Attendance(){
  const [email, setEmail] = useState('');
  const [logs, setLogs] = useState([]);

  useEffect(()=>{ fetchLogs(); },[]);

  async function fetchLogs(){
    try{
      const res = await axios.get('http://localhost:5000/api/attendance');
      setLogs(res.data);
    }catch(e){ console.error(e); }
  }

  async function punch(type){
    if(!email) { alert('Enter email'); return; }
    await axios.post('http://localhost:5000/api/attendance/punch', { user_email: email, type });
    setEmail('');
    fetchLogs();
  }

  return (
    <div>
      <h3>Attendance Punch</h3>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="your email" />
        <button onClick={()=>punch('in')}>Punch In</button>
        <button onClick={()=>punch('out')}>Punch Out</button>
      </div>
      <div>
        <h4>Recent logs</h4>
        <ul>
          {logs.slice().reverse().map(l=>(
            <li key={l.id}>{l.user_email} — {l.type} — {new Date(l.time).toLocaleString()}</li>
          ))}
        </ul>
      </div>
    </div>
  )
}