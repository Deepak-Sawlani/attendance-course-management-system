import React, {useState, useEffect} from 'react';
import axios from 'axios';

export default function Courses(){
  const [title,setTitle]=useState('');
  const [desc,setDesc]=useState('');
  const [courses,setCourses]=useState([]);

  useEffect(()=>{ fetchCourses(); },[]);

  async function fetchCourses(){
    try{
      const res = await axios.get('http://localhost:5000/api/courses');
      setCourses(res.data);
    }catch(e){ console.error(e); }
  }

  async function addCourse(){
    if(!title) return alert('Enter title');
    await axios.post('http://localhost:5000/api/courses', { title, description: desc });
    setTitle(''); setDesc('');
    fetchCourses();
  }

  async function deleteCourse(id){
    await axios.delete('http://localhost:5000/api/courses/' + id);
    fetchCourses();
  }

  return (
    <div>
      <h3>Course Management</h3>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Course title" />
        <input value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Short description" />
        <button onClick={addCourse}>Add Course</button>
      </div>
      <div>
        <h4>Courses</h4>
        <ul>
          {courses.map(c=>(
            <li key={c.id}>
              <strong>{c.title}</strong> — {c.description}
              <button style={{marginLeft:8}} onClick={()=>deleteCourse(c.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}